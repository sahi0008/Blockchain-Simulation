import hashlib
import time
import json

# Block class to define the structure of each block
class Block:
    def __init__(self, index, transactions, previous_hash, nonce=0):
        self.index = index
        self.timestamp = time.time()
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.hash = self.calculate_hash()

    # Hashing the block's content using SHA-256
    def calculate_hash(self):
        block_data = {
            "index": self.index,
            "timestamp": self.timestamp,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce
        }
        block_string = json.dumps(block_data, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    def __str__(self):
        return f"Block {self.index}: {self.hash}\nTransactions: {self.transactions}\n"


# Blockchain class to manage the chain of blocks
class Blockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]

    # Creating the first block (Genesis block)
    def create_genesis_block(self):
        return Block(0, ["Genesis Block"], "0")

    # Adding a new block with proof-of-work
    def add_block(self, transactions, difficulty=4):
        previous_block = self.chain[-1]
        new_block = Block(len(self.chain), transactions, previous_block.hash)
        
        # Proof-of-Work: Mine until the hash starts with '0' * difficulty
        while new_block.hash[:difficulty] != "0" * difficulty:
            new_block.nonce += 1
            new_block.hash = new_block.calculate_hash()

        self.chain.append(new_block)

    # Display the blockchain
    def display_chain(self):
        for block in self.chain:
            print(block)

    # Validate the blockchain integrity
    def validate_chain(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]

            if current.hash != current.calculate_hash():
                return False

            if current.previous_hash != previous.hash:
                return False
        return True

    # Tamper with the blockchain (for demonstration purposes)
    def tamper_chain(self, block_index, new_data):
        if block_index < len(self.chain):
            self.chain[block_index].transactions = new_data
            self.chain[block_index].hash = self.chain[block_index].calculate_hash()


# Main function
if __name__ == "__main__":
    # Create blockchain
    blockchain = Blockchain()

    # Add blocks
    blockchain.add_block(["Alice pays Bob 5 BTC"])
    blockchain.add_block(["Bob pays Charlie 3 BTC"])
    blockchain.add_block(["Charlie pays Dave 2 BTC"])

    print("\n✅ Original Blockchain:")
    blockchain.display_chain()

    # Validate blockchain
    print("\n🔍 Validating Blockchain:", "Valid" if blockchain.validate_chain() else "Corrupted")

    # Tamper with the blockchain
    print("\n⚠️ Tampering with Block 2...")
    blockchain.tamper_chain(2, ["Hacked Transaction"])

    print("\n🔍 Blockchain after Tampering:")
    blockchain.display_chain()

    # Validate after tampering
    print("\n🔍 Validating Blockchain after tampering:", "Valid" if blockchain.validate_chain() else "Corrupted")
